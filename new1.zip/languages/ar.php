<?php
$lang = array(
    "welcome_message" => "مرحبًا بكم في SaveFromIG!",
    "enter_instagram_url" => "أدخل رابط Instagram هنا...",
    "download" => "تنزيل",
    "post" => "نشر",
    "description" => "SaveFromIG.com هو الحل الأمثل لتنزيل الصور والفيديوهات من Instagram. قم بتنزيل محتوى Instagram المفضل لديك بسهولة وسرعة باستخدام خدمتنا. يوفر SaveFromIG تنزيلات عالية الجودة مجانًا. فقط أدخل رابط Instagram واستمتع بوصول غير محدود إلى المحتوى المفضل لديك."
);
?>
